var app = angular.module("gameSite", []); /* New module called gamesite */

