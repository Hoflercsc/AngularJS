
app.directive("mainPageNavbar", function() {
    return {
        
        templateUrl : 'views/main-page/navbar.html'

    };
});

app.directive("mainPageContent", function() {
    return {
        
        templateUrl : 'views/main-page/main-content.html'
    };
});


app.directive("mainPageFooter", function() {
    return {
        
        templateUrl : 'views/main-page/footer.html'
    };
});

